#!/usr/bin/python3
# -*-coding:UTF-8 -*
'''
Created on 12 october 2020
@author: Christine PLUMEJEAUD-PERREAU, U.M.R 7266 LIENSs
Master 2 course : Web programming with python

TP for Flask templates
Used to read and parse data coming from the data.portic.fr API
Then sends the parsed content toward a Flask template like a table
'''
from flask import Flask, render_template

import http.client
from io import StringIO, BytesIO, TextIOWrapper
import json
import pandas as pd


app = Flask(__name__)



def getStateForDate(jsonelement, dateparam):
    """
    jsonelement : [{"1749-1815" : "Toscane"},{"1801-1807" : "Royaume d'Étrurie"},{"1808-1814" : "Empire français"}]
    Internal method to output state for 1787 as dateparam
    return name of the state of the period including dateparam 
    state = getStateForDate(json.load(StringIO('[{"1749-1815" : "Toscane"},{"1801-1807" : "Royaume d'Étrurie"},{"1808-1814" : "Empire français"}]')), 1787)
    """
    eltjson = json.loads(jsonelement) 
    for k in eltjson :
        for dates, state in k.items():
            datesarray = dates.split('-')
            start = datesarray[0]
            end = datesarray[1]
            if (int(start) <= dateparam <= int(end)):
                return state
            


def getPorticData() :
    '''
    you grab data from another Web server
    https://docs.python.org/3.7/library/http.client.html#httpresponse-objects
    #target_url = "http://data.portic.fr/api/ports/?shortenfields=false&both_to=false&date=1787"
    '''
    conn = http.client.HTTPConnection("data.portic.fr")

    
    conn.request("GET", "/api/ports/?shortenfields=false&both_to=false&date=1787")
    r1 = conn.getresponse()
    data1 = r1.read()  # This will return entire content.
    b = BytesIO(data1)
    b.seek(0) #Start of stream (the default).  pos should be  = 0;
    data = json.load(b)

    ## If you read data in a file on your server
    '''
    with open('ports.json', encoding="utf-8") as f:
        data = json.load(f)
    '''

    ## Create a dataframe out of json
    df = pd.DataFrame(data)

    
    # Dealing with null values
    df.admiralty.isnull().values.any() #True 
    values = {'admiralty': 'X'}
    df = df.fillna(value=values)
    df.admiralty.isnull().values.any() #False 

    # Listing of admiralties
    df.admiralty.unique() # array(['X'], dtype=object)
    df.admiralty.unique().size #52

    # How many ports by admiralty ?
    df.groupby('admiralty')['ogc_fid'].count()

    # How many ports by belonging_states ?
    df.groupby('belonging_states')['ogc_fid'].count()
 
                        
    #https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html
    for elt in df['belonging_states'].unique():
        if elt is None :
            df.loc[df.belonging_states.eq(elt), 'state_1787'] = 'X' 
        else :
            state = getStateForDate(elt, 1787)
            if state is not None:
                df.loc[df.belonging_states.eq(elt), 'state_1787'] = state

    ## Check the results
    df[['toponym', 'belonging_states', 'state_1787']]        
    df.shape

    type(df)
    df.loc[0, ['toponym', 'belonging_states', 'state_1787']]

    # How many ports by belonging_states ?
    df.groupby('state_1787')['ogc_fid'].count()

    return df

@app.route('/ports')
def show_ports():
    df = getPorticData()
    content = df.to_html()
    return render_template('hello.html', msg=content)


if __name__ == '__main__':
    app.run(debug=True, port=5050)

